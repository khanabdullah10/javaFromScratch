package classesAndObjects.shape;

abstract class Shape {

    abstract double area();

    abstract double perimeter();

}

